import {createIconSetFromIcoMoon} from 'react-native-vector-icons';
import Config from '../../assets/icons/selection.json';

export default createIconSetFromIcoMoon(Config, 'LightIcons');
